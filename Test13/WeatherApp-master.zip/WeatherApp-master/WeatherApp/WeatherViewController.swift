//
//  WeatherViewController.swift
//  WeatherApp
//
//  Created by student on 2018/12/16.
//  Copyright © 2018年 jerome. All rights reserved.
//

import UIKit
import Alamofire

class WeatherViewController: UIViewController {

    var cityCode : Int!
    
    @IBOutlet weak var temperature: UILabel!
    @IBOutlet weak var humidity: UILabel!
    @IBOutlet weak var airQuality: UILabel!
    // 以下五个属性均为optional值
    var json : [String:Any]!
    var cityInfo : [String:String]!
    var weatherData : [String:Any]!
    
    var todayData : [String]!
    var yesterdayData : [String:Any]!
    var forecast : [String:Any]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadWithAF()
    }
    
    func loadWithAF() {
        let site = "http://t.weather.sojson.com/api/weather/city/" + String(cityCode!)
        let url = URL(string: site)
        AF.request(url!).responseJSON { (response) in

            self.json = response.value! as? [String:Any]

            self.cityInfo = self.json["cityInfo"] as? [String:String]

            
            self.weatherData = self.json["data"] as? [String:Any]
            

            self.temperature.text = "温度："+(self.weatherData!["wendu"] as! String)
            self.humidity.text = "湿度："+(self.weatherData!["shidu"] as! String)
            self.airQuality.text = "空气质量："+(self.weatherData!["quality"] as! String)
            self.yesterdayData = self.weatherData["yesterday"] as? [String:Any]

        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
